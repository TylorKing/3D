                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1274733
Delta dimensional calibration tool by PurpleSensation is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

After suffering lot of hours of trying to calibrate my delta printer, I decided to calculate a more accurate method to approximate the diagonal correction, supposing calibrated z height, and this method involves the particular Horizontal Radius of your printer.

INSTRUCTIONS (Very recommended to read the pdf attached).

At first, set to 0 any correction on your X,Y or Z Diagonal rod and use your real diagonal rod length. You must use same diagonal rod value for each tower so the Excel can calculate particular corrections.
Then print the calibration piece on the CENTRE of the printing plate, like the one on the image.
You must avoid any thermal dilation on the printing, so, you must print with max cooling, the given resolution, not so slow, and not so fast, 40 mm/s for perimeters will be okay.

Then you must measure the distance between faces on each tower direction and introduce them on the spreadsheet document on "Thing Files".

The pre-set distance is 75 mm, if you scale the piece you must edit that parameter on the Excel document.

- Instructions of the Excel document on the Excel document.

- Explanation of the method on the PDF

- It's a very good idea to remove the wall dilation of the measurement.

#Tips

- On slic3r, use 90% (for example) perimeter extrusion, on advanced settings, so print becomes more accurate.

- Use brim, may increase precision.

- Do not remove the hexagon from the printing bed, measure it without removing.

#Version History

1.1
- Redesigned spreadsheet to recieve the raw measurement.
- Redesigned the calibration hexagon to give it more rigidity and use thinner walls, so wall dilation is less important.



# Print Settings

Printer: DIY Delta
Rafts: No
Supports: No
Resolution: 0.2
Infill: Nope

Notes: 
Use just 2 perimeters, check the image from the slicing on top.

# How I Designed This

Some maths and... voilá!